#from django.conf import settings as django_settings

APP_LABEL = 'wiki'

# Key for django_notify - changing it will break any existing notifications.
ARTICLE_EDIT = "article_edit"

SLUG = 'notifications'