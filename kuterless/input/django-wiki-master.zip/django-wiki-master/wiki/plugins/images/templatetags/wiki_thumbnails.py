from sorl.thumbnail.templatetags.thumbnail import register
