# Add your own changes here -- but do not push to remote!!
# After changing the file, from root of repository execute:

# git update-index --assume-unchanged testproject/testproject/settings/local.py
